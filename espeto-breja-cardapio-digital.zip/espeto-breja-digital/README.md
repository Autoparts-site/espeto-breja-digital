# Espeto & Breja — Cardápio Digital com QR Code

Aplicação web pronta para publicar. Possui:
- `/menu`: cardápio público responsivo.
- `/admin`: painel protegido por login.
- Dois administradores iniciais: `joao` / `12345678` e `hariel` / `12345678`.
- Troca de senha pelo próprio painel; ao trocar, as sessões antigas desse usuário são invalidadas.
- Edição, inclusão e exclusão de itens e preços.
- Edição do Instagram e link de avaliação do Google.
- `/api/qr.png`: QR Code que aponta para `/menu` no domínio atual.
- SQLite local, senhas com hash bcrypt e cookie HTTP-only.

## Rodar localmente
1. Instale Node.js 20+.
2. Copie `.env.example` para `.env`.
3. Defina `JWT_SECRET` com uma chave longa e aleatória.
4. Execute `npm install`.
5. Execute `npm start`.
6. Abra `http://localhost:3000/menu`.
7. Painel: `http://localhost:3000/admin`.

## Publicação
Publique esta pasta em um serviço que rode Node.js e mantenha armazenamento persistente para `data/menu.sqlite`. Defina `NODE_ENV=production`, `JWT_SECRET` e `PORT` no ambiente. Depois de publicado, baixe o QR em `/api/qr.png` e use-o na impressão/placa.

## Segurança
Troque as duas senhas padrão imediatamente após a publicação. O HTTPS deve ser usado em produção. Não compartilhe o arquivo `.env`.
