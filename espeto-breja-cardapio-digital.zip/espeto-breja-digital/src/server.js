import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import cookieParser from 'cookie-parser';
import Database from 'better-sqlite3';
import QRCode from 'qrcode';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

dotenv.config();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const dataDir = path.join(root, 'data');
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(process.env.DB_FILE || path.join(dataDir, 'menu.sqlite'));
db.pragma('journal_mode = WAL');

const defaultMenu = [
  {section:'ESPETOS', name:'Carne', price:10}, {section:'ESPETOS', name:'Frango', price:10},
  {section:'ESPETOS', name:'Tulipa de frango', price:10}, {section:'ESPETOS', name:'Kafta c/ catupiry', price:12},
  {section:'ESPETOS', name:'Kafta c/ queijo', price:11}, {section:'ESPETOS', name:'Picanha suína', price:10},
  {section:'ESPETOS', name:'Panceta', price:10}, {section:'ESPETOS', name:'Medalhão de quiabo', price:10},
  {section:'ESPETOS', name:'Medalhão de frango', price:10}, {section:'ESPETOS', name:'Medalhão de queijo', price:10},
  {section:'ESPETOS', name:'Medalhão de mandioca', price:12}, {section:'ESPETOS', name:'Linguiça', price:10},
  {section:'ESPETOS', name:'Linguiça c/ pimenta', price:10}, {section:'ESPETOS', name:'Coração', price:10},
  {section:'ESPETOS', name:'Carneiro', price:14}, {section:'ESPETOS', name:'Queijo coalho', price:10},
  {section:'ESPETOS', name:'Pão de alho', price:9}, {section:'ESPETOS', name:'Pão de doce de leite', price:10},
  {section:'ESPETOS', name:'Romeu e Julieta', price:10},
  {section:'PORÇÕES', name:'Batata frita', price:25}, {section:'PORÇÕES', name:'Batata frita com catupiry e bacon', price:50},
  {section:'PORÇÕES', name:'Calabresa acebolada', price:30}, {section:'PORÇÕES', name:'Bolinho de linguiça (6 uni)', price:28},
  {section:'PORÇÕES', name:'Torresmo', price:13}, {section:'PORÇÕES', name:'Arroz', price:8}, {section:'PORÇÕES', name:'Mandioca', price:8},
  {section:'PORÇÕES', name:'Jantinha — 1 espeto (carne, frango ou kafta), arroz, mandioca, farofa e vinagrete.', price:23},
  {section:'BEBIDAS', name:'Chopp', price:7}, {section:'BEBIDAS', name:'Brahma 600ml', price:12}, {section:'BEBIDAS', name:'Skol 600ml', price:12},
  {section:'BEBIDAS', name:'Antártica Boa 600ml', price:12}, {section:'BEBIDAS', name:'Heineken 600ml', price:16},
  {section:'BEBIDAS', name:'Original 600ml', price:15.5}, {section:'BEBIDAS', name:'Amstel 600ml', price:13},
  {section:'BEBIDAS', name:'Império 600ml', price:10}, {section:'BEBIDAS', name:'Império Lager 600ml', price:11},
  {section:'BEBIDAS', name:'Império Ultra', price:8}, {section:'BEBIDAS', name:'Heineken Zero', price:9},
  {section:'BEBIDAS', name:'Caipirinha', price:14}, {section:'BEBIDAS', name:'Ice', price:10}, {section:'BEBIDAS', name:'Coca-Cola 1L', price:9},
  {section:'BEBIDAS', name:'Guaraná Antártica 1L', price:9}, {section:'BEBIDAS', name:'Coca-Cola lata', price:6},
  {section:'BEBIDAS', name:'Coca-Cola Zero', price:6}, {section:'BEBIDAS', name:'Guaraná Antártica lata', price:6},
  {section:'BEBIDAS', name:'Guaraná Antártica Zero', price:6}, {section:'BEBIDAS', name:'Sprite Lemon Fresh', price:6},
  {section:'BEBIDAS', name:'Suco', price:15}, {section:'BEBIDAS', name:'Água', price:4}, {section:'BEBIDAS', name:'Água com gás', price:5}
];

const schema = `
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, display_name TEXT NOT NULL, password_hash TEXT NOT NULL, password_version INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS items (id INTEGER PRIMARY KEY AUTOINCREMENT, section TEXT NOT NULL, name TEXT NOT NULL, price REAL NOT NULL, sort_order INTEGER NOT NULL DEFAULT 0);
`;
db.exec(schema);
const count = db.prepare('SELECT COUNT(*) c FROM items').get().c;
if (!count) {
  const ins = db.prepare('INSERT INTO items(section,name,price,sort_order) VALUES(?,?,?,?)');
  const tx = db.transaction(() => defaultMenu.forEach((x,i)=>ins.run(x.section,x.name,x.price,i)));
  tx();
}
const userCount = db.prepare('SELECT COUNT(*) c FROM users').get().c;
if (!userCount) {
  const ins = db.prepare('INSERT INTO users(username,display_name,password_hash) VALUES(?,?,?)');
  ins.run('joao','João',bcrypt.hashSync('12345678',12));
  ins.run('hariel','Hariel',bcrypt.hashSync('12345678',12));
}
const defaults = {
  instagram:'https://www.instagram.com/_espetoebreja?stkn=MWdrZzQ5eHVycXQ2YQ==',
  googleReview:'https://share.google/CwHAyleDilNZRO9nl',
  title:'Espeto & Breja',
  subtitle:'Bons espetos, bebidas geladas e momentos especiais!'
};
const set = db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)');
for (const [k,v] of Object.entries(defaults)) set.run(k,v);

const app = express();
app.use(helmet({ contentSecurityPolicy:false }));
app.use(express.json({limit:'200kb'}));
app.use(cookieParser());
app.use(express.static(path.join(root,'public')));
const loginLimiter = rateLimit({windowMs:15*60*1000,max:10,standardHeaders:true,legacyHeaders:false});

function settings(){ return Object.fromEntries(db.prepare('SELECT key,value FROM settings').all().map(r=>[r.key,r.value])); }
function auth(req,res,next){
  const token=req.cookies.eb_admin;
  if(!token) return res.status(401).json({error:'Não autenticado'});
  try {
    const p=jwt.verify(token,process.env.JWT_SECRET || 'dev-only-change-me');
    const u=db.prepare('SELECT id,username,display_name,password_version FROM users WHERE id=?').get(p.uid);
    if(!u || u.password_version!==p.pv) throw new Error('invalid');
    req.user=u; next();
  } catch { res.clearCookie('eb_admin'); return res.status(401).json({error:'Sessão inválida'}); }
}

app.get('/api/menu',(req,res)=>res.json({settings:settings(),items:db.prepare('SELECT id,section,name,price,sort_order FROM items ORDER BY sort_order,id').all()}));
app.post('/api/login',loginLimiter,(req,res)=>{
  const {username,password}=req.body||{};
  const u=db.prepare('SELECT * FROM users WHERE username=?').get(String(username||'').trim().toLowerCase());
  if(!u || !bcrypt.compareSync(String(password||''),u.password_hash)) return res.status(401).json({error:'Usuário ou senha inválidos'});
  const token=jwt.sign({uid:u.id,pv:u.password_version},process.env.JWT_SECRET || 'dev-only-change-me',{expiresIn:'8h'});
  res.cookie('eb_admin',token,{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:8*60*60*1000});
  res.json({user:{username:u.username,name:u.display_name}});
});
app.post('/api/logout',auth,(req,res)=>{res.clearCookie('eb_admin');res.json({ok:true});});
app.get('/api/me',auth,(req,res)=>res.json({username:req.user.username,name:req.user.display_name}));
app.put('/api/settings',auth,(req,res)=>{
  const allowed=['instagram','googleReview','title','subtitle'];
  const up=db.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value');
  for(const k of allowed) if(typeof req.body[k]==='string') up.run(k,req.body[k]);
  res.json({settings:settings()});
});
app.put('/api/items/:id',auth,(req,res)=>{
  const id=Number(req.params.id); const {name,price,section}=req.body;
  if(!name || !Number.isFinite(Number(price)) || !['ESPETOS','PORÇÕES','BEBIDAS'].includes(section)) return res.status(400).json({error:'Dados inválidos'});
  db.prepare('UPDATE items SET name=?,price=?,section=? WHERE id=?').run(name,Number(price),section,id); res.json({ok:true});
});
app.post('/api/items',auth,(req,res)=>{
  const {name,price,section}=req.body;
  if(!name || !Number.isFinite(Number(price)) || !['ESPETOS','PORÇÕES','BEBIDAS'].includes(section)) return res.status(400).json({error:'Dados inválidos'});
  const max=db.prepare('SELECT COALESCE(MAX(sort_order),0) m FROM items').get().m;
  const r=db.prepare('INSERT INTO items(section,name,price,sort_order) VALUES(?,?,?,?)').run(name,Number(price),section,max+1);
  res.json({id:r.lastInsertRowid});
});
app.delete('/api/items/:id',auth,(req,res)=>{db.prepare('DELETE FROM items WHERE id=?').run(Number(req.params.id));res.json({ok:true});});
app.put('/api/password',auth,(req,res)=>{
  const {currentPassword,newPassword}=req.body||{};
  if(!newPassword || String(newPassword).length<8) return res.status(400).json({error:'A nova senha deve ter pelo menos 8 caracteres'});
  const u=db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
  if(!bcrypt.compareSync(String(currentPassword||''),u.password_hash)) return res.status(400).json({error:'Senha atual incorreta'});
  db.prepare('UPDATE users SET password_hash=?,password_version=password_version+1 WHERE id=?').run(bcrypt.hashSync(String(newPassword),12),u.id);
  res.clearCookie('eb_admin'); res.json({ok:true});
});
app.get('/api/qr.png',async(req,res)=>{
  try { const base=`${req.protocol}://${req.get('host')}`; const buf=await QRCode.toBuffer(`${base}/menu`,{width:800,margin:2,color:{dark:'#111111',light:'#ffffff'}}); res.type('png').send(buf); } catch(e){res.status(500).end();}
});
app.get('/menu',(req,res)=>res.sendFile(path.join(root,'public','menu.html')));
app.get('/admin',(req,res)=>res.sendFile(path.join(root,'public','admin.html')));
app.get('/',(req,res)=>res.redirect('/menu'));

const port=Number(process.env.PORT||3000);
app.listen(port,()=>console.log(`Espeto & Breja em http://localhost:${port}`));
